package org.homebrew;

import java.awt.*;
import javax.tv.xlet.*;
import org.havi.ui.*;

public class Xlet extends Container implements javax.tv.xlet.Xlet {

    private HScene scene;
    private Font font;

    public void initXlet(XletContext context) {
        // Set standard 720p Blu-ray resolution
        setSize(1280, 720);
        
        // Grab the default Blu-ray screen scene
        scene = HSceneFactory.getInstance().getDefaultHScene();
        scene.add(this);
        scene.validate();
    }

    public void startXlet() {
        setVisible(true);
        scene.setVisible(true);
        repaint();
    }

    public void pauseXlet() {
        setVisible(false);
    }

    public void destroyXlet(boolean unconditional) {
        if (scene != null) {
            scene.remove(this);
            scene = null;
        }
    }

    public void paint(Graphics g) {
        // Draw a dark background
        g.setColor(new Color(20, 20, 40));
        g.fillRect(0, 0, getWidth(), getHeight());

        // Render "Hello World!"
        if (font == null) {
            font = new Font(null, Font.BOLD, 48);
        }
        g.setFont(font);
        g.setColor(Color.WHITE);
        g.drawString("Hello World!", 480, 360);
    }
}
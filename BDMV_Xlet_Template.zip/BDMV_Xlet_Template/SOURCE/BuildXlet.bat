@echo off
echo ========================================
echo Compiling Bejeweled BD-J Engine (Java 1.3)
echo ========================================

javac -source 1.3 -target 1.3 -Xlint:-options -classpath "lib\bdj.jar" src\org\homebrew\*.java src\org\homebrew\engine\*.java

echo.
echo ========================================
if exist src\org\homebrew\MyXlet.class (
    echo SUCCESS: All classes generated successfully!
) else (
    echo FAILED: Check errors above.
)
echo ========================================
pause